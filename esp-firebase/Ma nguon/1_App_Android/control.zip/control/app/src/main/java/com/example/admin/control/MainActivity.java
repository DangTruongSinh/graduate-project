package com.example.admin.control;

import android.content.ContextWrapper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static android.content.Context.MODE_PRIVATE;

public class MainActivity extends AppCompatActivity {
    public static final String TAG = MainActivity.class.getSimpleName();
    Switch lock;
    private DatabaseReference mDatabase;
    TextView temp, hum, numBattery;
    ImageView img,battery;
    AsyncTask mMyTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        numBattery = findViewById(R.id.txtBattery);
        battery = findViewById(R.id.imageView4);
        img = (ImageView) findViewById(R.id.imageView3);
        temp = findViewById(R.id.txtTemp);
        hum = findViewById(R.id.txtHum);
        lock = findViewById(R.id.switch1);
        lock.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true) {
                    mDatabase.child("khoa").setValue("on");
                } else {
                    mDatabase.child("khoa").setValue("off");
                }
            }
        });

        mDatabase.child("doam").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                hum.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(TAG, "Failed to read value 'doam'.", databaseError.toException());
            }
        });

        mDatabase.child("nhietdo").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                temp.setText(dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(TAG, "Failed to read value 'nhietdo'.", databaseError.toException());
            }
        });

        mDatabase.child("khoa").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue().toString().equals("on")) {
                    lock.setChecked(true);
                } else {
                    lock.setChecked(false);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(TAG, "Failed to read value 'khoa'.", databaseError.toException());
            }
        });

        mDatabase.child("url").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull final DataSnapshot dataSnapshot) {
                if (dataSnapshot.getValue().toString().contains("http")) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            new DownloadImageFromInternet().execute(dataSnapshot.getValue().toString());
                        }
                    });
                }
                else{
                    Toast.makeText(MainActivity.this, "sai", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(TAG, "Failed to read value 'url'.", databaseError.toException());
            }
        });

        mDatabase.child("pin").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int data = Integer.parseInt(dataSnapshot.getValue().toString());
                numBattery.setText(dataSnapshot.getValue().toString());
                if(data > 100){
                    battery.setImageResource(R.drawable.battery6);
                }
                else if(data > 80){
                    battery.setImageResource(R.drawable.battery1);
                }
                else if(data > 60){
                    battery.setImageResource(R.drawable.battery2);
                }
                else if(data > 40){
                    battery.setImageResource(R.drawable.battery3);
                }
                else if(data > 20){
                    battery.setImageResource(R.drawable.battery4);
                }
                else if(data > 10){
                    battery.setImageResource(R.drawable.battery5);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w(TAG, "Failed to read value 'pin'.", databaseError.toException());
            }
        });
    }


    private class DownloadImageFromInternet extends AsyncTask<String, Void, Bitmap> {

        @Override
        protected Bitmap doInBackground(String... strings) {
            Bitmap bmp = null;
            try {
                URL u = new URL((strings[0]));
                bmp = BitmapFactory.decodeStream(u.openConnection().getInputStream());

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bmp;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            img.setImageBitmap(bitmap);
        }
    }
}


